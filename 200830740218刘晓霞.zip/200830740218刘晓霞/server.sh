java -jar server.jar
