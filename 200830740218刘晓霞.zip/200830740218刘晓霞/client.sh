java -jar client.jar
