package util;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import model.ConstEnum;
import model.Msg;

/**
 *
 * @author NC
 */
public class SocketUtil {

    public static ObjectOutputStream getWriter(Socket socket) throws IOException {
        OutputStream socketOut = socket.getOutputStream();
        ObjectOutputStream data = new ObjectOutputStream(socketOut);
        return data;
    }

    public static ObjectInputStream getReader(Socket socket) throws IOException {
        InputStream socketIn = socket.getInputStream();
        ObjectInputStream data = new ObjectInputStream(socketIn);
        return data;
    }

    public static void close(Socket socket, InputStream in, OutputStream out) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException ex) {
                Logger.getLogger(SocketUtil.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (out != null) {
            try {
                out.close();
            } catch (IOException ex) {
                Logger.getLogger(SocketUtil.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException ex) {
                Logger.getLogger(SocketUtil.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static String log(DefaultListModel logs, String msg) {
        String s = "log:" + msg;
        System.out.println(s);
        logs.addElement(s);
        return s;
    }

    public static String log_say(DefaultListModel logs, Msg msg) {
        String s = msg.getFrom() + " 对 " + msg.getTo() + " 说:" + msg.getInfo();
        System.out.println(s);
        logs.addElement(s);
        return s;
    }

    public static void serverError() {
        try {
            JOptionPane.showMessageDialog(null, "服务器端出现了问题，本窗口即将关闭");
            Thread.sleep(50);
            System.exit(0);
        } catch (InterruptedException ex) {
            Logger.getLogger(SocketUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static String joinWithSplit(Object[] set) {
        StringBuilder sb = new StringBuilder();
        for (Object s : set) {
            if (false == s.equals(ConstEnum.All.toString())) {
                sb.append(s).append(ConstEnum.split.toString());
            }
        }
        //去掉最后一个split
        sb.delete(sb.lastIndexOf(ConstEnum.split.toString()), sb.length());
        return sb.toString();
    }

    public static void alert(String s) {
        JOptionPane.showMessageDialog(null, s);
    }


    /*
     * 使用正则表达式判断ip地址是否正确
     */
    public static boolean testIP(String ip) {
        //((不能以0打头的一位数和两位数|100-200|200-249|250-255).){3}(不能以0打头的一位数和两位数|100-200|200-249|250-255))
        String regex = "((([1-9]\\d{0,1})|(1\\d{2})|(2[0-4]\\d)|(25[0-5]))\\.){3}(([1-9]\\d{0,1})|(1\\d{2})|(2[0-4]\\d)|(25[0-5]))";
        Pattern p = Pattern.compile(regex);// 预编译这个正则表达式,使速度更快
        Matcher m = p.matcher(ip);// 进行匹配
        System.out.println("ip:" + ip);
        //return m.matches();// 返回匹配结果
        return true;
    }

    public static int testPort(String p) {
        int port = -1;
        try {
            port = Integer.parseInt(p);
            if (port > 65535 || port < 0) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            SocketUtil.alert(p + " 不是一个合法的端口!");
            return -1;
        }
        return port;
    }
}
