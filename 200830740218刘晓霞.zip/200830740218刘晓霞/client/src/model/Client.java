package model;

import util.SocketUtil;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import view.ChatClient;
import view.ChatServer;

/**
 *
 * @author NC
 */
public class Client implements Runnable {

    private Socket socket = null;
    private int port;
    private String host;
    private String name;
    private ObjectInputStream in = null;
    private ObjectOutputStream out = null;
    private DefaultListModel infoModel;
    private DefaultListModel clients;
    private boolean logined;

    public Client(String host, int port, DefaultListModel info, DefaultListModel receiever) {
        this.host = host;
        this.port = port;
        this.infoModel = info;
        this.clients = receiever;
    }

    public void logout() {
        Msg msg = new Msg();
        msg.setFrom(name);
        msg.setInfo("我想注销~");
        msg.setTo(ConstEnum.Server.toString());
        msg.setCmd(CmdEnum.logout);
        sendMessage(msg, infoModel);
    }

    public boolean login(String name) throws UnknownHostException, IOException {
        //初始化
        socket = new Socket(host, port);
        out = SocketUtil.getWriter(socket);
        in = SocketUtil.getReader(socket);
        //发送登录的命令
        Msg request = new Msg();
        request.setCmd(CmdEnum.login);
        request.setFrom(name);
        request.setTo(ConstEnum.Server.toString());
        request.setInfo("我想登录~");
        out.writeObject(request);
        out.flush();
        SocketUtil.log_say(infoModel, request);
        this.name = name;
        //服务器响应
        try {
            Object obj = null;
            while ((obj = in.readObject()) != null) {
                Msg reponse = (Msg) obj;
                CmdEnum cmd = reponse.getCmd();
                switch (cmd) {
                    case loginFail:
                        SocketUtil.alert(reponse.getInfo());
                        SocketUtil.log_say(infoModel, reponse);
                        return false;
                    case loginSuccess:
                        SocketUtil.alert(reponse.getInfo());
                        SocketUtil.log_say(infoModel, reponse);
                        logined = true;
                        new Thread(this).start();
                        return true;
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            SocketUtil.close(socket, in, out);
            return false;
        }
        return false;
    }

    public boolean isLogined() {
        return logined;
    }

    public String getName() {
        return name;
    }

    @Override
    public void run() {
        try {
            Object obj = null;
            while ((obj = in.readObject()) != null) {
                Msg reponse = (Msg) obj;
                CmdEnum cmd = reponse.getCmd();
                switch (cmd) {
                    case serverMsg:
                        SocketUtil.log_say(infoModel, reponse);
                        break;
                    case updateClient:
                        String[] list = reponse.getInfo().split(ConstEnum.split.toString());
                        clients.removeAllElements();
                        for (int i = 0; i < list.length; i++) {
                            clients.addElement(list[i]);
                        }
                        break;
                    case wantToCall:
                        int rs = JOptionPane.showConfirmDialog(null, reponse.getFrom() + "想要跟您聊天？可以吗？");
                        if (rs == JOptionPane.OK_OPTION) {
                            //这个端口是固定的~~~
                            ChatServer frame = new ChatServer(reponse,52000);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                            Msg msg = new Msg();
                            msg.setFrom(name);
                            msg.setTo(reponse.getFrom());
                            msg.setInfo(frame.getIp() + ":" + frame.getPort());
                            msg.setCmd(CmdEnum.letWeTalk);
                            sendMessage(msg, null);
                        } else {
                            sendMessage(name, reponse.getFrom(), "不想跟你聊天！", CmdEnum.refuseToChat, null);
                        }
                        break;
                    case refuseToChat:
                        JOptionPane.showMessageDialog(null, reponse.getFrom() + reponse.getInfo());
                        break;
                    case letWeTalk:
                        JOptionPane.showMessageDialog(null, "您可以跟" + reponse.getFrom() + "聊天了");
                        String[] sss = reponse.getInfo().split(":");
                        ChatClient frame = new ChatClient(sss[0], Integer.parseInt(sss[1]), reponse);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);
                        break;
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            SocketUtil.close(socket, in, out);
        }
    }

    public void sendMessage(Msg m, DefaultListModel model) {
        try {
            //TODO这里不能够再次out = SocketUtil.getWriter(socket);
            out.writeObject(m);
            out.flush();
            if (model != null) {
                SocketUtil.log_say((DefaultListModel) model, m);
            }
        } catch (IOException ex) {
            Logger.getLogger(SocketUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendMessage(String from, String to, String info, CmdEnum cmd,
            DefaultListModel model) {
        Msg m = new Msg();
        m.setCmd(cmd);
        m.setFrom(from);
        m.setInfo(info);
        m.setTo(to);
        sendMessage(m, model);
    }
}
