package model;

/**
 *
 * @author NC
 */
public enum ConstEnum {

    Server, All, split;

    @Override
    public String toString() {
        if (split.equals(this)) {
            return "#";
        } else {
            return super.toString();
        }
    }
}
