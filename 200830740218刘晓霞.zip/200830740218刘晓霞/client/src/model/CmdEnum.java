package model;

/**
 *
 * @author NC
 */
public enum CmdEnum {

    logout, login, loginFail, loginSuccess,
    serverMsg, clientMsg, updateClient,
    wantToCall, refuseToChat,letWeTalk
}
