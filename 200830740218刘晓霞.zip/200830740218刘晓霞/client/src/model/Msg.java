package model;

import java.io.Serializable;

/**
 *
 * @author NC
 */
public class Msg implements Serializable {

    private String from;
    private String to;
    private String info;
    private CmdEnum cmd;

    public CmdEnum getCmd() {
        return cmd;
    }

    public void setCmd(CmdEnum cmd) {
        this.cmd = cmd;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }
}
