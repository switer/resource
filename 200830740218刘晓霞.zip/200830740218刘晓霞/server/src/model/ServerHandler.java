package model;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import util.SocketUtil;

/**
 *
 * @author NC
 */
public class ServerHandler implements Runnable {

    private Socket socket;
    private String ID;
    //服务端的日志记录
    private DefaultListModel infoModel;
    //连接的客户端记录
    private DefaultListModel clientsModel;
    //发消息的列表(接收者列表)
    private DefaultComboBoxModel recieversModel;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private HashMap<String, ServerHandler> handlers;

    public ServerHandler(Socket socket,
            DefaultListModel clientsModel, DefaultListModel infoModel,
            DefaultComboBoxModel recieversModel,
            HashMap<String, ServerHandler> handlers) {
        this.socket = socket;
        this.clientsModel = clientsModel;
        this.infoModel = infoModel;
        this.recieversModel = recieversModel;
        this.handlers = handlers;
    }

    public void sendMessage(String from, String to, String info, CmdEnum cmd) {
        Msg m = new Msg();
        m.setCmd(cmd);
        m.setFrom(from);
        m.setInfo(info);
        m.setTo(to);
        sendMessage(m);
    }

    public void sendMessage(Msg m) {
        try {
            if (out == null) {
                out = SocketUtil.getWriter(socket);
            }
            //TODO 这一句要在out前面
            SocketUtil.log_say(infoModel, m);
            out.writeObject(m);
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(ServerHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateClients(Msg m) {
        try {
            if (out == null) {
                out = SocketUtil.getWriter(socket);
            }
            out.writeObject(m);
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(ServerHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateClients(String from, String to, String info, CmdEnum cmd) {
        Msg m = new Msg();
        m.setCmd(cmd);
        m.setFrom(from);
        m.setInfo(info);
        m.setTo(to);
        updateClients(m);
    }

    @Override
    public void run() {
        try {
            Object obj = null;
            String name = null;
            out = SocketUtil.getWriter(socket);
            in = SocketUtil.getReader(socket);
            //不断地监听来自客户端的登录命令
            while ((obj = in.readObject()) != null) {
                Msg request = (Msg) obj;
                CmdEnum cmd = request.getCmd();
                name = request.getFrom();//获取登录的用户名
                switch (cmd) {
                    case login:
                        if (clientsModel.contains(name)) {
                            sendMessage(ConstEnum.Server.toString(), name, "这个账号已经登录过了！", CmdEnum.loginFail);
                        } else {
                            sendMessage(ConstEnum.Server.toString(), name, "欢迎您！", CmdEnum.loginSuccess);
                            ID = name;
                            clientsModel.addElement(name);
                            recieversModel.addElement(name);
                            handlers.put(name, this);
                            updateClients();
                        }
                        break;
                    case clientMsg:
                        if (request.getTo().equals(ConstEnum.Server.toString())) {
                            SocketUtil.log_say(infoModel, request);
                        } else {
                            forwardAll(request);
                        }
                        break;
                    case logout:
                        clientsModel.removeElement(name);
                        recieversModel.removeElement(name);
                        handlers.remove(name);
                        updateClients();
                        SocketUtil.log(infoModel, request.getFrom() + " 下线了！");
                        break;
                    case wantToCall:
                        forward(request);
                        break;
                    case letWeTalk:
                        forward(request);
                        break;
                    case refuseToChat:
                        forward(request);
                        break;
                }
            }
        } catch (Exception e) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    /**
     * 群发更新在线人数
     */
    public void updateClients() {
        for (ServerHandler handler : handlers.values()) {
            handler.updateClients(
                    ConstEnum.Server.toString(), ConstEnum.All.toString(),
                    SocketUtil.joinWithSplit(handlers.keySet().toArray()),
                    CmdEnum.updateClient);
        }
    }

    /**
     * 转发多人
     * 转发命令为serverMsg
     * @param msg 
     */
    public void forwardAll(Msg msg) {
        String[] clients = msg.getTo().split(ConstEnum.split.toString());
        for (String client : clients) {
            handlers.get(client).sendMessage(msg.getFrom(), client, msg.getInfo(), CmdEnum.serverMsg);
        }
    }

    /**
     * 转发
     * 转发命令不变
     * @param msg 
     */
    public void forward(Msg msg) {
        handlers.get(msg.getTo()).sendMessage(msg);
    }

    public void stop() {
        if (socket != null) {
            try {
                //服务端的日志记录
                infoModel.removeElement(ID);
                clientsModel.removeElement(ID);
                recieversModel.removeElement(ID);
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
                handlers.remove(ID);
                socket.close();
            } catch (IOException ex) {
                Logger.getLogger(ServerHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
