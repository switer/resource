package model;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import util.SocketUtil;

/**
 * @author NC
 */
public class Server implements Runnable {

    private int port = 8000;
    private ServerSocket serverSocket = null;
    //是否开始
    private boolean isStarted = false;
    //服务端的日志记录
    private DefaultListModel infoModel;
    //连接的客户端记录
    private DefaultListModel clientsModel;
    //发消息的列表(接收者列表)
    private DefaultComboBoxModel recieversModel;
    //当前的所有客户端处理线程
    private HashMap<String, ServerHandler> handlers = new HashMap<String, ServerHandler>();

    public Server(int port,
            DefaultListModel infoModel, DefaultListModel clients,
            DefaultComboBoxModel recieversModel) {
        this.port = port;
        this.infoModel = infoModel;
        this.clientsModel = clients;
        this.recieversModel = recieversModel;
    }

    public ServerHandler getHandler(String name) {
        return handlers.get(name);
    }

    public boolean isIsStarted() {
        return isStarted;
    }

    public void service() {
        try {
            serverSocket = new ServerSocket(port);
            new Thread(this).start();
            isStarted = true;
            SocketUtil.log(infoModel, "服务器启动");
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendMessageToAll(String msg) {
        for (ServerHandler handler : handlers.values()) {
            handler.sendMessage(ConstEnum.Server.toString(), ConstEnum.All.toString(), msg, CmdEnum.serverMsg);
        }
    }

    public void stop() {
        try {
            isStarted = false;
            if (serverSocket != null) {
                serverSocket.close();
            }
            serverSocket = null;
            SocketUtil.log(infoModel, "服务器停止");
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {
        while (isStarted) {
            try {
                Socket socket = null;
                socket = serverSocket.accept();//监听客户端连接
                StringBuilder sb = new StringBuilder();
                sb.append("新连接建立").
                        append(socket.getInetAddress()).append(":").append(socket.getPort());
                SocketUtil.log(infoModel, sb.toString());
                //建立连接后，分派处理线程
                ServerHandler handler =
                        new ServerHandler(socket, clientsModel, infoModel, recieversModel, handlers);
                new Thread(handler).start();
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                SocketUtil.log(infoModel, "服务器出现异常");
                stop();
            }
        }
    }
}
